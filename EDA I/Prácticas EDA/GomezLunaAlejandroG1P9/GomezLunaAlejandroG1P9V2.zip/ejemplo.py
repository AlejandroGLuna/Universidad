def main():
    lista=[11,12,13,14,15,16,17,18]
    valor1=0
    valor2=1
    for i in lista:
        valor1+=i
    for j in lista:
        valor2*=j
    print(valor1)
    print(valor2)

main()