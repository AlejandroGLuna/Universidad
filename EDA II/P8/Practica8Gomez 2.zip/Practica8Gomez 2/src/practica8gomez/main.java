package practica8gomez;

public class main {
    public static void main(String[] args) {
        Menu.generarMenu();
        /*ArbolBin arbol;
        Nodo n7=new Nodo(7);
        Nodo n9=new Nodo(9);
        Nodo n1=new Nodo(1,n7,n9);
        Nodo n15=new Nodo(15);
        Nodo n8=new Nodo(8);
        Nodo n4=new Nodo(4);
        Nodo n2=new Nodo(2);
        Nodo n16=new Nodo(16);
        Nodo n3=new Nodo(3);
        arbol =new ArbolBin(n1);
        arbol.add(n7,n15,0);
        arbol.add(n7,n8,1);
        arbol.add(n9,n4,0);
        arbol.add(n9,n2,1);
        arbol.add(n15,n16,1);
        arbol.add(n8,n3,0);
        arbol.breadthFirst();
        System.out.println();
        arbol.breadthFirst();
        System.out.println("Se encuentra el elemento 16: "+arbol.busqueda(16));
        System.out.println("Se encuentra el elemento 9: "+arbol.busqueda(9));
        System.out.println("Se encuentra el elemento 0: "+arbol.busqueda(0));
        Nodo a0=new Nodo(8);
        Nodo a1=new Nodo(3);
        Nodo a2=new Nodo(1);
        Nodo a3=new Nodo(6);
        Nodo a4=new Nodo(4);
        Nodo a5=new Nodo(7);
        Nodo a6=new Nodo(10);
        Nodo a7=new Nodo(14);
        Nodo a8=new Nodo(13);
        ArbolBinBusqueda arbinbu=new ArbolBinBusqueda(a0);
        arbinbu.add(a1);
        arbinbu.add(a6);
        arbinbu.add(a7);
        arbinbu.add(a8);
        arbinbu.add(a2);
        arbinbu.add(a3);
        arbinbu.add(a4);
        arbinbu.add(a5);
        arbinbu.breadthFirst();
        arbinbu.datosArbol();
        arbinbu.eliminarNodo(a6);
        System.out.println();
        arbinbu.breadthFirst();
        arbinbu.eliminarNodo(a0);
        System.out.println();
        arbinbu.breadthFirst();
        arbinbu.datosArbol();*/
    }
}
