package practica7;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int V =8;
        Graph graph =new Graph(V);
        graph.addEdgeIndirected(1,5);
        graph.addEdgeIndirected(5,7);
        graph.addEdgeIndirected(4,5);
        graph.addEdgeIndirected(4,7);
        graph.addEdgeIndirected(7,3);
        graph.addEdgeIndirected(4,0);
        graph.addEdgeIndirected(0,2);
        graph.addEdgeIndirected(0,6);
        //graph.aristaNoDirigida(sc, graph);
        System.out.println("UDF con arista 5 ");
        graph.DFS(5);
        System.out.println("UDF con arista 3 ");
        graph.DFS(3);
        System.out.println("DF con arista 4 ");
        graph.DFS(4);
    }
}
