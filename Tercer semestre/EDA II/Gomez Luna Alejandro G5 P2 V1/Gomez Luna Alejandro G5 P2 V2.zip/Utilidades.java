package practica2gomez;

public class Utilidades{
	static void printArray(int arr[]){
		int n=arr.length;
		for (int i=0;i<n ;++i ) 
			System.out.println(arr[i]+" ");
		System.out.println();
	}
}

