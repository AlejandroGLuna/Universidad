//
//  main.c
//  Practica5
//
//  Created by Gomez Luna Alejandro on 3/11/19.
//  Copyright © 2019 Gomez Luna Alejandro. All rights reserved.
//

#include "Pila.h"

int main(){
    printf("vamos a crear una pila \n");
    Pila miPila = crearPila();
    printf("vamos a ingresar algunos elementos \n");
    meter(&miPila,10);
    meter(&miPila,20);
    meter(&miPila,30);
    printf("El valor de tope es: %d \n",miPila.tope);//recuerda que el tope es un Ìndice
    int a = sacar(&miPila);
    int b = sacar(&miPila);
    int c = sacar(&miPila);

    int d = sacar(&miPila);
    printf("valor de c es: %d \n",c);
    system("PAUSE");
    return 0xAF;
}


